<!-- Trends & Analytics view - loaded via admin_app.php -->
<!-- Header Section -->
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-md mb-xl">
<div>
<h1 class="font-display-lg text-display-lg text-on-surface">Trends &amp; Analytics</h1>
<p class="font-body-lg text-body-lg text-on-surface-variant mt-xs">Comprehensive overview of waste generation and recycling efficiency.</p>
</div>
<div class="flex gap-sm">
<select id="trend-year-filter" class="bg-surface-container-lowest border border-outline-variant rounded-DEFAULT px-lg py-sm text-primary font-label-md text-label-md hover:bg-surface-container-low transition-colors shadow-sm focus:outline-none focus:border-primary cursor-pointer">
<option value="all">All Years</option>
</select>
<button id="export-trends-btn" class="flex items-center gap-sm px-lg py-sm bg-primary text-on-primary rounded-DEFAULT font-label-md text-label-md hover:bg-primary/90 transition-colors shadow-sm">
<span class="material-symbols-outlined text-sm">download</span>
                        Export Data
                    </button>
</div>
</div>
<!-- Metrics Overview (Bento Grid) -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-lg mb-xl">
<!-- Card 1 -->
<div class="bg-surface-container-lowest border border-outline-variant rounded-xl p-lg shadow-card relative overflow-hidden group">
<div class="absolute -right-8 -top-8 w-32 h-32 bg-primary-container/20 rounded-full blur-2xl group-hover:bg-primary-container/30 transition-colors"></div>
<div class="flex justify-between items-start mb-md relative z-10">
<div>
<p class="font-label-md text-label-md text-on-surface-variant uppercase tracking-wider">Total Waste Collected</p>
<h2 class="font-headline-lg text-headline-lg text-on-surface mt-xs"><span id="total-waste-value">—</span> <span class="font-title-md text-title-md text-on-surface-variant">Tons</span></h2>
</div>
<div class="w-10 h-10 rounded-full bg-surface-container flex items-center justify-center text-primary">
<span class="material-symbols-outlined">delete_sweep</span>
</div>
</div>
<div class="flex items-center gap-xs relative z-10">
<span class="flex items-center font-label-md text-label-md text-error bg-error-container/50 px-xs py-0.5 rounded-sm">
<span class="material-symbols-outlined text-[14px]">arrow_upward</span>
                            4.2%
                        </span>
<span class="font-body-sm text-body-sm text-on-surface-variant">vs last year</span>
</div>
</div>
<!-- Card 2 -->
<div class="bg-surface-container-lowest border border-outline-variant rounded-xl p-lg shadow-card relative overflow-hidden group">
<div class="absolute -right-8 -top-8 w-32 h-32 bg-secondary-container/20 rounded-full blur-2xl group-hover:bg-secondary-container/30 transition-colors"></div>
<div class="flex justify-between items-start mb-md relative z-10">
<div>
<p class="font-label-md text-label-md text-on-surface-variant uppercase tracking-wider">Recycling Rate</p>
<h2 class="font-headline-lg text-headline-lg text-on-surface mt-xs"><span id="recycling-rate-value">—</span> <span class="font-title-md text-title-md text-on-surface-variant">%</span></h2>
</div>
<div class="w-10 h-10 rounded-full bg-surface-container flex items-center justify-center text-secondary">
<span class="material-symbols-outlined">recycling</span>
</div>
</div>
<div class="flex items-center gap-xs relative z-10">
<span class="flex items-center font-label-md text-label-md text-status-success-text bg-status-success/50 px-xs py-0.5 rounded-sm">
<span class="material-symbols-outlined text-[14px]">arrow_upward</span>
                            8.5%
                        </span>
<span class="font-body-sm text-body-sm text-on-surface-variant">vs last year</span>
</div>
<!-- Mini Progress Bar -->
<div class="w-full h-1.5 bg-surface-container-highest rounded-full mt-md overflow-hidden">
<div id="recycling-progress" class="h-full bg-secondary w-[0%] rounded-full"></div>
</div>
</div>
<!-- Card 3 -->
<div class="bg-surface-container-lowest border border-outline-variant rounded-xl p-lg shadow-card relative overflow-hidden group">
<div class="absolute -right-8 -top-8 w-32 h-32 bg-tertiary-container/20 rounded-full blur-2xl group-hover:bg-tertiary-container/30 transition-colors"></div>
<div class="flex justify-between items-start mb-md relative z-10">
<div>
<p class="font-label-md text-label-md text-on-surface-variant uppercase tracking-wider">CO2 Emissions Avoided</p>
<h2 class="font-headline-lg text-headline-lg text-on-surface mt-xs"><span id="co2-value">—</span> <span class="font-title-md text-title-md text-on-surface-variant">MT</span></h2>
</div>
<div class="w-10 h-10 rounded-full bg-surface-container flex items-center justify-center text-tertiary">
<span class="material-symbols-outlined">co2</span>
</div>
</div>
<div class="flex items-center gap-xs relative z-10">
<span class="flex items-center font-label-md text-label-md text-status-success-text bg-status-success/50 px-xs py-0.5 rounded-sm">
<span class="material-symbols-outlined text-[14px]">arrow_upward</span>
                            12.1%
                        </span>
<span class="font-body-sm text-body-sm text-on-surface-variant">vs last year</span>
</div>
</div>
</div>
<!-- Charts Section (Main Bento Area) -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-lg mb-xl">
<!-- Main Area Chart: Volume Over Time -->
<div class="bg-surface-container-lowest border border-outline-variant rounded-xl shadow-card flex flex-col lg:col-span-2 overflow-hidden">
<div class="p-lg border-b border-surface-container-highest flex justify-between items-center bg-status-tableheader/30">
<div>
<h3 class="font-title-lg text-title-lg text-on-surface">Waste Volume vs Recycled</h3>
<p class="font-body-sm text-body-sm text-on-surface-variant mt-xs">Monthly tracking (Tons)</p>
</div>
<div class="flex gap-sm">
<div class="flex items-center gap-xs">
<div class="w-3 h-3 rounded-full bg-primary"></div>
<span class="font-label-md text-label-md text-on-surface-variant">Total Waste</span>
</div>
<div class="flex items-center gap-xs">
<div class="w-3 h-3 rounded-full bg-secondary"></div>
<span class="font-label-md text-label-md text-on-surface-variant">Recycled</span>
</div>
</div>
</div>
<div class="p-lg flex-1 relative min-h-[300px]">
<canvas class="w-full h-full" id="volumeChart" width="792" height="289" style="display: block; box-sizing: border-box; height: 289.4px; width: 792.7px;"></canvas>
</div>
</div>
<!-- Secondary Chart: Efficiency Gauge -->
<div class="bg-surface-container-lowest border border-outline-variant rounded-xl shadow-card flex flex-col overflow-hidden">
<div class="p-lg border-b border-surface-container-highest bg-status-tableheader/30">
<h3 class="font-title-lg text-title-lg text-on-surface">Recycling Efficiency</h3>
<p class="font-body-sm text-body-sm text-on-surface-variant mt-xs">Current Month Goal: 45%</p>
</div>
<div class="p-lg flex-1 flex flex-col items-center justify-center relative min-h-[300px]"><div class="relative w-64 h-32 overflow-hidden flex items-end justify-center"><div class="absolute top-0 left-0 w-64 h-64 rounded-full border-[24px] border-surface-container-highest"></div><div class="absolute top-0 left-0 w-64 h-64 rounded-full border-[24px] border-primary border-b-transparent border-r-transparent transform -rotate-45" style="transform: rotate(-13deg);"></div><div class="relative z-10 flex flex-col items-center pb-sm mb-2"><div id="efficiency-gauge-value" class="font-display-lg text-display-lg text-primary leading-none">—</div><div class="font-body-md text-body-md text-on-surface-variant font-medium">Efficiency Rate</div></div><div class="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-4 bg-primary rounded-full z-20 border-2 border-surface-container-lowest"></div></div>
<div class="mt-lg w-full flex justify-between text-body-sm text-on-surface-variant px-xl">
    <span class="">0%</span>
    <span class="font-medium text-primary">Target: 45%</span>
    <span class="">100%</span>
</div></div>
</div>
</div>
<!-- Lower Section: Regional & Year over Year -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-lg mb-xl">
<!-- Regional Distribution Bar Chart -->
<div class="bg-surface-container-lowest border border-outline-variant rounded-xl shadow-card flex flex-col overflow-hidden">
<div class="p-lg border-b border-surface-container-highest flex justify-between items-center bg-status-tableheader/30">
<h3 class="font-title-lg text-title-lg text-on-surface">Regional Distribution</h3>
</div>
<div class="p-lg flex-1 relative min-h-[300px]">
<canvas class="w-full h-full" id="regionalChart" width="576" height="252" style="display: block; box-sizing: border-box; height: 252px; width: 576px;"></canvas>
</div>
</div>
<!-- Year-over-Year Comparison Table -->
<div class="bg-surface-container-lowest border border-outline-variant rounded-xl shadow-card flex flex-col overflow-hidden">
<div class="p-lg border-b border-surface-container-highest bg-status-tableheader/30">
<h3 class="font-title-lg text-title-lg text-on-surface">Year-over-Year Reduction Metrics</h3>
</div>
<div class="flex-1 overflow-x-auto">
<table class="w-full text-left border-collapse">
<thead>
<tr class="bg-status-tableheader text-on-surface-variant font-label-md text-label-md uppercase tracking-wider">
<th class="p-md font-medium border-b border-surface-container-highest">Category</th>
<th class="p-md font-medium border-b border-surface-container-highest text-right">2023 (Tons)</th>
<th class="p-md font-medium border-b border-surface-container-highest text-right">2024 (Tons)</th>
<th class="p-md font-medium border-b border-surface-container-highest text-right">Change</th>
</tr>
</thead>
<tbody id="yoy-tbody" class="font-body-md text-body-md text-on-surface divide-y divide-surface-container-high">
<tr class="hover:bg-surface-container-lowest transition-colors">
<td class="p-md py-sm">General Waste</td>
<td class="p-md py-sm text-right">850.5</td>
<td class="p-md py-sm text-right">795.2</td>
<td class="p-md py-sm text-right">
<span class="inline-flex items-center gap-xs text-status-success-text bg-status-success/50 px-xs py-0.5 rounded-sm font-label-md text-label-md">
<span class="material-symbols-outlined text-[14px]">arrow_downward</span> 6.5%
                                        </span>
</td>
</tr>
<tr class="hover:bg-surface-container-lowest transition-colors">
<td class="p-md py-sm">Recyclables</td>
<td class="p-md py-sm text-right">410.2</td>
<td class="p-md py-sm text-right">450.6</td>
<td class="p-md py-sm text-right">
<span class="inline-flex items-center gap-xs text-status-success-text bg-status-success/50 px-xs py-0.5 rounded-sm font-label-md text-label-md">
<span class="material-symbols-outlined text-[14px]">arrow_upward</span> 9.8%
                                        </span>
</td>
</tr>
<tr class="hover:bg-surface-container-lowest transition-colors">
<td class="p-md py-sm">Organic</td>
<td class="p-md py-sm text-right">320.0</td>
<td class="p-md py-sm text-right">305.5</td>
<td class="p-md py-sm text-right">
<span class="inline-flex items-center gap-xs text-status-success-text bg-status-success/50 px-xs py-0.5 rounded-sm font-label-md text-label-md">
<span class="material-symbols-outlined text-[14px]">arrow_downward</span> 4.5%
                                        </span>
</td>
</tr>
<tr class="hover:bg-surface-container-lowest transition-colors">
<td class="p-md py-sm">Hazardous</td>
<td class="p-md py-sm text-right">45.8</td>
<td class="p-md py-sm text-right">52.1</td>
<td class="p-md py-sm text-right">
<span class="inline-flex items-center gap-xs text-error bg-error-container/50 px-xs py-0.5 rounded-sm font-label-md text-label-md">
<span class="material-symbols-outlined text-[14px]">arrow_upward</span> 13.7%
                                        </span>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<!-- Chart Scripts -->
<script>
        (function() {
            "use strict";
            var D = window.EcoWasteData;
            if (!D || !localStorage.getItem("sb-access-token")) return;

            // Colors from Tailwind config
            var primaryColor = '#630ed4';
            var primaryContainerColor = '#7c3aed';
            var secondaryColor = '#4648d4';
            var surfaceHighest = '#e5e1e4';
            var onSurfaceVariant = '#4a4455';

var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var CO2_FACTOR = 0.94; // metric tons CO2e avoided per ton recycled (EPA-derived assumption)

            // Chart.js Default Settings
            Chart.defaults.font.family = "'Hanken Grotesk', sans-serif";
            Chart.defaults.color = onSurfaceVariant;
            Chart.defaults.scale.grid.color = surfaceHighest;

            var volumeData = [];
            var regionalData = [];
            var yoyData = [];
            var currentYear = "all";

            async function load() {
                volumeData = await D.list("monthly_volume", "year,month,total_waste_tons,recycled_tons", "year.asc,month.asc");
                regionalData = await D.list("regional_stats", "region,waste_tons", "waste_tons.desc");
                yoyData = await D.list("yoy_metrics", "category,tons_2023,tons_2024");

                populateYearFilter();
                applyYear();
                renderRegionalChart(regionalData);
                renderYoy(yoyData);
            }

            function populateYearFilter() {
                var sel = document.getElementById("trend-year-filter");
                if (!sel) return;
                var years = [];
                volumeData.forEach(function (r) {
                    var y = String(r.year);
                    if (years.indexOf(y) === -1) years.push(y);
                });
                years.sort().reverse();
                years.forEach(function (y) {
                    var opt = document.createElement("option");
                    opt.value = y;
                    opt.textContent = y;
                    sel.appendChild(opt);
                });
                sel.addEventListener("change", function () {
                    currentYear = sel.value;
                    applyYear();
                });
            }

            function filteredVolume() {
                if (currentYear === "all") return volumeData;
                return volumeData.filter(function (r) { return String(r.year) === currentYear; });
            }

            function applyYear() {
                var vol = filteredVolume();
                var labels = vol.map(function (r) { return MONTHS[(Number(r.month) - 1) % 12]; });
                var totalData = vol.map(function (r) { return Number(r.total_waste_tons) || 0; });
                var recycledData = vol.map(function (r) { return Number(r.recycled_tons) || 0; });

                var totalTons = totalData.reduce(function (a, b) { return a + b; }, 0);
                var recycledTons = recycledData.reduce(function (a, b) { return a + b; }, 0);
                var rate = totalTons > 0 ? (recycledTons / totalTons) * 100 : 0;

                setKpis(totalTons, rate);
                var co2El = document.getElementById("co2-value");
                if (co2El) co2El.textContent = D.fmtNum(Math.round(recycledTons * CO2_FACTOR * 10) / 10);
                renderVolumeChart(labels, totalData, recycledData);
            }

            function exportTrends() {
                var lines = [];
                var vol = filteredVolume();
                lines.push("SECTION,Monthly Collection Volume,,,,");
                lines.push("Year,Month,Total Waste (Tons),Recycled (Tons),,");
                vol.forEach(function (r) {
                    lines.push([D.csvCell(r.year), D.csvCell(r.month), D.csvCell(r.total_waste_tons), D.csvCell(r.recycled_tons), D.csvCell(""), D.csvCell("")].join(","));
                });
                lines.push("SECTION,Regional Distribution,,,,");
                lines.push("Region,Waste (Tons),,,,");
                regionalData.forEach(function (r) {
                    lines.push([D.csvCell(r.region), D.csvCell(r.waste_tons), D.csvCell(""), D.csvCell(""), D.csvCell(""), D.csvCell("")].join(","));
                });
                lines.push("SECTION,Year over Year,,,,");
                lines.push("Category,2023 (Tons),2024 (Tons),Change %,,");
                yoyData.forEach(function (r) {
                    var a = Number(r.tons_2023) || 0;
                    var b = Number(r.tons_2024) || 0;
                    var diff = a > 0 ? ((b - a) / a) * 100 : 0;
                    lines.push([D.csvCell(r.category), D.csvCell(a), D.csvCell(b), D.csvCell(diff.toFixed(1) + "%"), D.csvCell(""), D.csvCell("")].join(","));
                });
                D.exportBlob("ecowaste_trends_data.csv", lines.join("\r\n"), "text/csv;charset=utf-8;");
            }

            function setKpis(totalTons, rate) {
                var totalEl = document.getElementById("total-waste-value");
                if (totalEl) totalEl.textContent = D.fmtNum(totalTons);
                var rateEl = document.getElementById("recycling-rate-value");
                if (rateEl) rateEl.textContent = rate.toFixed(1);
                var progress = document.getElementById("recycling-progress");
                if (progress) progress.style.width = rate.toFixed(1) + "%";
                var gauge = document.getElementById("efficiency-gauge-value");
                if (gauge) gauge.textContent = rate.toFixed(1) + "%";
            }

            function renderVolumeChart(labels, totalData, recycledData) {
                var canvas = document.getElementById('volumeChart');
                if (!canvas || typeof Chart === "undefined") return;
                var volumeCtx = canvas.getContext('2d');

                var gradientPrimary = volumeCtx.createLinearGradient(0, 0, 0, 400);
                gradientPrimary.addColorStop(0, 'rgba(99, 14, 212, 0.2)');
                gradientPrimary.addColorStop(1, 'rgba(99, 14, 212, 0)');

                var gradientSecondary = volumeCtx.createLinearGradient(0, 0, 0, 400);
                gradientSecondary.addColorStop(0, 'rgba(70, 72, 212, 0.2)');
                gradientSecondary.addColorStop(1, 'rgba(70, 72, 212, 0)');

                new Chart(volumeCtx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [
                            {
                                label: 'Total Waste (Tons)',
                                data: totalData,
                                borderColor: primaryColor,
                                backgroundColor: gradientPrimary,
                                borderWidth: 2,
                                fill: true,
                                tension: 0.4,
                                pointRadius: 0,
                                pointHoverRadius: 6
                            },
                            {
                                label: 'Recycled (Tons)',
                                data: recycledData,
                                borderColor: secondaryColor,
                                backgroundColor: gradientSecondary,
                                borderWidth: 2,
                                fill: true,
                                tension: 0.4,
                                pointRadius: 0,
                                pointHoverRadius: 6
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                mode: 'index',
                                intersect: false,
                                backgroundColor: 'rgba(28, 27, 29, 0.9)',
                                titleFont: { size: 13, family: "'Hanken Grotesk', sans-serif" },
                                bodyFont: { size: 14, family: "'Hanken Grotesk', sans-serif" },
                                padding: 12,
                                cornerRadius: 4
                            }
                        },
                        scales: {
                            x: { grid: { display: false } },
                            y: { beginAtZero: true, border: { display: false } }
                        },
                        interaction: { mode: 'nearest', axis: 'x', intersect: false }
                    }
                });
            }

            function renderRegionalChart(rows) {
                var canvas = document.getElementById('regionalChart');
                if (!canvas || typeof Chart === "undefined") return;
                new Chart(canvas.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: rows.map(function (r) { return r.region; }),
                        datasets: [{
                            label: 'Waste Generation (Tons)',
                            data: rows.map(function (r) { return Number(r.waste_tons) || 0; }),
                            backgroundColor: primaryContainerColor,
                            borderRadius: 4,
                            barPercentage: 0.6
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                backgroundColor: 'rgba(28, 27, 29, 0.9)',
                                titleFont: { size: 13 },
                                bodyFont: { size: 14 },
                                padding: 12,
                                cornerRadius: 4
                            }
                        },
                        scales: {
                            x: { grid: { display: false } },
                            y: { beginAtZero: true, border: { display: false } }
                        }
                    }
                });
            }

            function renderYoy(rows) {
                var tbody = document.getElementById("yoy-tbody");
                if (!tbody) return;
                tbody.innerHTML = "";
                if (!rows.length) {
                    tbody.innerHTML = '<tr><td class="p-md py-sm text-on-surface-variant" colspan="4">No year-over-year data.</td></tr>';
                    return;
                }
                rows.forEach(function (r) {
                    var a = Number(r.tons_2023) || 0;
                    var b = Number(r.tons_2024) || 0;
                    var diff = a > 0 ? ((b - a) / a) * 100 : 0;
                    var up = diff >= 0;
                    var arrow = up ? 'arrow_upward' : 'arrow_downward';
                    var isBad = up && r.category === 'Hazardous';
                    var badge = isBad
                        ? 'text-error bg-error-container/50'
                        : 'text-status-success-text bg-status-success/50';
                    var tr = document.createElement("tr");
                    tr.className = "hover:bg-surface-container-lowest transition-colors";
                    tr.innerHTML =
                        '<td class="p-md py-sm">' + D.esc(r.category) + '</td>' +
                        '<td class="p-md py-sm text-right">' + D.esc(D.fmtNum(a)) + '</td>' +
                        '<td class="p-md py-sm text-right">' + D.esc(D.fmtNum(b)) + '</td>' +
                        '<td class="p-md py-sm text-right">' +
                        '<span class="inline-flex items-center gap-xs px-xs py-0.5 rounded-sm font-label-md text-label-md ' + badge + '">' +
                        '<span class="material-symbols-outlined text-[14px]">' + arrow + '</span> ' + Math.abs(diff).toFixed(1) + '%' +
                        '</span></td>';
                    tbody.appendChild(tr);
                });
            }

load().catch(function (err) {
                console.error("EcoWaste trends data failed to load:", err);
            });

            var exportTrendsBtn = document.getElementById("export-trends-btn");
            if (exportTrendsBtn) {
                exportTrendsBtn.addEventListener("click", exportTrends);
            }
        })();
    </script>


